title: 我在 GitHub 上的开源项目
date: '2019-11-14 11:04:59'
updated: '2019-11-14 11:04:59'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [BookManager](https://github.com/gzcxe/BookManager) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/gzcxe/BookManager/watchers "关注数")&nbsp;&nbsp;[⭐️`2`](https://github.com/gzcxe/BookManager/stargazers "收藏数")&nbsp;&nbsp;[🖖`1`](https://github.com/gzcxe/BookManager/network/members "分叉数")</span>

图书管理系统(JavaWeb)



---

### 2. [gzcxe.github.io](https://github.com/gzcxe/gzcxe.github.io) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/gzcxe/gzcxe.github.io/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/gzcxe/gzcxe.github.io/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/gzcxe/gzcxe.github.io/network/members "分叉数")&nbsp;&nbsp;[🏠`https://gzcxe.github.io`](https://gzcxe.github.io "项目主页")</span>

hexo个人博客



---

### 3. [shunlume](https://github.com/gzcxe/shunlume) <kbd title="主要编程语言">HTML</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/gzcxe/shunlume/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/gzcxe/shunlume/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/gzcxe/shunlume/network/members "分叉数")</span>

大二参加服务外包比赛的部分项目，没有后台，只有前端页面展示

